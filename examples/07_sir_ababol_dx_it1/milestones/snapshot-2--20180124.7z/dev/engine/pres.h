// NES MK1 v1.0
// Copyleft Mojon Twins 2013, 2015, 2017

// Cutscene

unsigned char cutsi, cutc, cutf, cutff;
unsigned char *cuts_text;

