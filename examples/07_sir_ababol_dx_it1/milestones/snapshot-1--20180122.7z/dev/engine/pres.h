// NES MK1 v0.7
// Copyleft Mojon Twins 2013, 2015, 2016

// Cutscene

unsigned char cutsi, cutc, cutf, cutff;
unsigned char *cuts_text;

